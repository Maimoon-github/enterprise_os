"""
Entrypoint for streamlit, see https://docs.streamlit.io/
"""

import asyncio
import base64
import os
import subprocess
import traceback
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import StrEnum
from functools import partial
from pathlib import PosixPath
from typing import Any, cast, get_args

import httpx2 as httpx
import streamlit as st
from anthropic import RateLimitError
from anthropic.types.beta import (
    BetaContentBlockParam,
    BetaTextBlockParam,
    BetaToolResultBlockParam,
)
from streamlit.delta_generator import DeltaGenerator

from computer_use_demo.loop import (
    APIProvider,
    ThinkingEffort,
    ThinkingMode,
    sampling_loop,
)
from computer_use_demo.tools import ToolResult, ToolVersion

PROVIDER_TO_DEFAULT_MODEL_NAME: dict[APIProvider, str] = {
    APIProvider.ANTHROPIC: "claude-opus-4-8",
    APIProvider.BEDROCK: "anthropic.claude-3-5-sonnet-20241022-v2:0",
    APIProvider.VERTEX: "claude-3-5-sonnet-v2@20241022",
}


@dataclass(kw_only=True, frozen=True)
class ModelConfig:
    tool_version: ToolVersion
    max_output_tokens: int
    default_output_tokens: int
    # Thinking modes this model accepts, in preference order; the first entry is
    # the default the UI selects. See ThinkingMode in loop.py.
    thinking_modes: tuple[ThinkingMode, ...] = ("off", "extended")


CLAUDE_4 = ModelConfig(
    tool_version="computer_use_20250429",
    max_output_tokens=64_000,
    default_output_tokens=1024 * 16,
    thinking_modes=("off", "extended"),
)

CLAUDE_4_5 = ModelConfig(
    tool_version="computer_use_20250124",
    max_output_tokens=128_000,
    default_output_tokens=1024 * 16,
    thinking_modes=("off", "extended"),
)

CLAUDE_4_WITH_ZOOMABLE_TOOL = ModelConfig(
    tool_version="computer_use_20251124",
    max_output_tokens=64_000,
    default_output_tokens=1024 * 16,
    thinking_modes=("off", "extended"),
)

HAIKU_4_5 = ModelConfig(
    tool_version="computer_use_20250124",
    max_output_tokens=1024 * 8,
    default_output_tokens=1024 * 4,
    thinking_modes=("off",),
)

# Claude Opus 4.6 / Sonnet 4.6 introduce adaptive thinking (the model decides
# how much to reason, steered by an effort level). They still accept the older
# extended-thinking budget for backwards compatibility, but adaptive is the
# recommended default.
CLAUDE_4_6 = ModelConfig(
    tool_version="computer_use_20251124",
    max_output_tokens=128_000,
    default_output_tokens=1024 * 16,
    thinking_modes=("adaptive", "extended", "off"),
)

# Claude Opus 4.7 and later only support adaptive thinking; requests with a
# manual thinking budget are rejected by the API.
CLAUDE_4_7 = ModelConfig(
    tool_version="computer_use_20251124",
    max_output_tokens=128_000,
    default_output_tokens=1024 * 16,
    thinking_modes=("adaptive", "off"),
)

# Fallback for model IDs not listed in MODEL_TO_MODEL_CONF. Thinking defaults to
# off (safe for any model), but every mode is selectable so newer models can be
# used by typing their ID and picking "adaptive" manually.
DEFAULT_MODEL_CONF = ModelConfig(
    tool_version="computer_use_20250429",
    max_output_tokens=64_000,
    default_output_tokens=1024 * 16,
    thinking_modes=("off", "adaptive", "extended"),
)

MODEL_TO_MODEL_CONF: dict[str, ModelConfig] = {
    "claude-opus-4-1-20250805": CLAUDE_4,
    "claude-opus-4-1": CLAUDE_4,
    "claude-sonnet-4-20250514": CLAUDE_4,
    "claude-opus-4-20250514": CLAUDE_4,
    "claude-sonnet-4-5-20250929": CLAUDE_4_5,
    "anthropic.claude-sonnet-4-5-20250929-v1:0": CLAUDE_4_5,
    "claude-sonnet-4-5@20250929": CLAUDE_4_5,
    "claude-sonnet-4-5": CLAUDE_4_5,
    "claude-haiku-4-5-20251001": HAIKU_4_5,
    "anthropic.claude-haiku-4-5-20251001-v1:0": HAIKU_4_5,  # Bedrock
    "claude-haiku-4-5@20251001": HAIKU_4_5,  # Vertex
    "claude-haiku-4-5": HAIKU_4_5,
    "claude-opus-4-5-20251101": CLAUDE_4_WITH_ZOOMABLE_TOOL,
    "claude-opus-4-5": CLAUDE_4_WITH_ZOOMABLE_TOOL,
    "claude-opus-4-6": CLAUDE_4_6,
    "claude-sonnet-4-6": CLAUDE_4_6,
    "claude-opus-4-7": CLAUDE_4_7,
    "claude-opus-4-8": CLAUDE_4_7,
}


def _lookup_model_conf(model: str) -> ModelConfig:
    """Resolve a model ID to its config.

    Tries an exact match first, then the longest known key that the ID starts
    with, so undated aliases, newly dated snapshots, and the Bedrock / Vertex
    forms of a known model family resolve to the right config instead of
    falling through to the permissive default. Offering a thinking mode the
    model doesn't support produces an API error, so a correct lookup matters.
    """
    if model in MODEL_TO_MODEL_CONF:
        return MODEL_TO_MODEL_CONF[model]
    # anthropic.claude-sonnet-4-5-20250929-v1:0 -> claude-sonnet-4-5-20250929...
    normalized = model.removeprefix("anthropic.").replace("@", "-")
    prefix_matches = [k for k in MODEL_TO_MODEL_CONF if normalized.startswith(k)]
    if prefix_matches:
        return MODEL_TO_MODEL_CONF[max(prefix_matches, key=len)]
    return DEFAULT_MODEL_CONF


CONFIG_DIR = PosixPath("~/.anthropic").expanduser()
API_KEY_FILE = CONFIG_DIR / "api_key"
STREAMLIT_STYLE = """
<style>
    /* Highlight the stop button in red */
    button[kind=header] {
        background-color: rgb(255, 75, 75);
        border: 1px solid rgb(255, 75, 75);
        color: rgb(255, 255, 255);
    }
    button[kind=header]:hover {
        background-color: rgb(255, 51, 51);
    }
     /* Hide the streamlit deploy button */
    .stAppDeployButton {
        visibility: hidden;
    }
</style>
"""

WARNING_TEXT = "⚠️ Security Alert: Never provide access to sensitive accounts or data, as malicious web content can hijack Claude's behavior"
INTERRUPT_TEXT = "(user stopped or interrupted and wrote the following)"
INTERRUPT_TOOL_ERROR = "human stopped or interrupted tool execution"


class Sender(StrEnum):
    USER = "user"
    BOT = "assistant"
    TOOL = "tool"


def setup_state():
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "api_key" not in st.session_state:
        # Try to load API key from file first, then environment
        st.session_state.api_key = load_from_storage("api_key") or os.getenv(
            "ANTHROPIC_API_KEY", ""
        )
    if "provider" not in st.session_state:
        st.session_state.provider = (
            os.getenv("API_PROVIDER", "anthropic") or APIProvider.ANTHROPIC
        )
    if "provider_radio" not in st.session_state:
        st.session_state.provider_radio = st.session_state.provider
    if "model" not in st.session_state:
        _reset_model()
    if "thinking_modes" not in st.session_state:
        # Covers sessions created before the thinking controls were added.
        _reset_model_conf()
    if "auth_validated" not in st.session_state:
        st.session_state.auth_validated = False
    if "responses" not in st.session_state:
        st.session_state.responses = {}
    if "tools" not in st.session_state:
        st.session_state.tools = {}
    if "only_n_most_recent_images" not in st.session_state:
        st.session_state.only_n_most_recent_images = 3
    if "custom_system_prompt" not in st.session_state:
        st.session_state.custom_system_prompt = load_from_storage("system_prompt") or ""
    if "hide_images" not in st.session_state:
        st.session_state.hide_images = False
    if "token_efficient_tools_beta" not in st.session_state:
        st.session_state.token_efficient_tools_beta = False
    if "in_sampling_loop" not in st.session_state:
        st.session_state.in_sampling_loop = False


def _reset_model():
    st.session_state.model = PROVIDER_TO_DEFAULT_MODEL_NAME[
        cast(APIProvider, st.session_state.provider)
    ]
    _reset_model_conf()


def _reset_model_conf():
    model_conf = _lookup_model_conf(st.session_state.model)

    # If we're in radio selection mode, use the selected tool version
    if hasattr(st.session_state, "tool_versions"):
        st.session_state.tool_version = st.session_state.tool_versions
    else:
        st.session_state.tool_version = model_conf.tool_version

    st.session_state.output_tokens = model_conf.default_output_tokens
    st.session_state.max_output_tokens = model_conf.max_output_tokens
    st.session_state.thinking_budget = int(model_conf.default_output_tokens / 2)
    st.session_state.thinking_modes = model_conf.thinking_modes
    st.session_state.thinking_mode = model_conf.thinking_modes[0]
    st.session_state.thinking_effort = "medium"


async def main():
    """Render loop for streamlit"""
    setup_state()

    st.markdown(STREAMLIT_STYLE, unsafe_allow_html=True)

    st.title("Claude Computer Use Demo")

    if not os.getenv("HIDE_WARNING", False):
        st.warning(WARNING_TEXT)

    with st.sidebar:

        def _reset_api_provider():
            if st.session_state.provider_radio != st.session_state.provider:
                _reset_model()
                st.session_state.provider = st.session_state.provider_radio
                st.session_state.auth_validated = False

        provider_options = [option.value for option in APIProvider]
        st.radio(
            "API Provider",
            options=provider_options,
            key="provider_radio",
            format_func=lambda x: x.title(),
            on_change=_reset_api_provider,
        )

        st.text_input("Model", key="model", on_change=_reset_model_conf)

        if st.session_state.provider == APIProvider.ANTHROPIC:
            st.text_input(
                "Claude API Key",
                type="password",
                key="api_key",
                on_change=lambda: save_to_storage("api_key", st.session_state.api_key),
            )

        st.number_input(
            "Only send N most recent images",
            min_value=0,
            key="only_n_most_recent_images",
            help="To decrease the total tokens sent, remove older screenshots from the conversation",
        )
        st.text_area(
            "Custom System Prompt Suffix",
            key="custom_system_prompt",
            help="Additional instructions to append to the system prompt. see computer_use_demo/loop.py for the base system prompt.",
            on_change=lambda: save_to_storage(
                "system_prompt", st.session_state.custom_system_prompt
            ),
        )
        st.checkbox("Hide screenshots", key="hide_images")
        st.checkbox(
            "Enable token-efficient tools beta", key="token_efficient_tools_beta"
        )
        versions = get_args(ToolVersion)
        st.radio(
            "Tool Versions",
            key="tool_versions",
            options=versions,
            index=versions.index(st.session_state.tool_version),
            on_change=lambda: setattr(
                st.session_state,
                "tool_version",
                st.session_state.get("tool_versions", st.session_state.tool_version),
            ),
        )

        st.number_input("Max Output Tokens", key="output_tokens", step=1)

        # Thinking controls. Which modes are offered depends on the selected
        # model: newer models (Opus 4.6 / Sonnet 4.6 and later) reason
        # adaptively, steered by an effort level, while older models take an
        # explicit thinking token budget. The options are derived from the
        # current model string (not cached state) and any selection that the
        # current model doesn't support is reset to its default, so an
        # unsupported mode can never be sent to the API for a known model.
        model_conf = _lookup_model_conf(st.session_state.model)
        thinking_modes = model_conf.thinking_modes
        st.session_state.thinking_modes = thinking_modes
        # The three thinking widgets below render conditionally, and Streamlit
        # deletes a widget's session_state key at the end of any run that
        # doesn't render it (e.g. picking "Off" removes the effort slider and,
        # with it, `thinking_effort`). Re-assigning the keys each run detaches
        # them from the widget lifecycle so the sampling loop can always read
        # them; the defaults cover a key that was already dropped.
        for key, default in (
            ("thinking_mode", thinking_modes[0]),
            ("thinking_effort", "medium"),
            ("thinking_budget", int(model_conf.default_output_tokens / 2)),
        ):
            st.session_state[key] = st.session_state.get(key, default)
        if st.session_state.thinking_mode not in thinking_modes:
            st.session_state.thinking_mode = thinking_modes[0]
        if model_conf is DEFAULT_MODEL_CONF:
            st.caption(
                "⚠️ Unrecognized model — all thinking modes are shown. Pick the "
                "one this model supports; an unsupported mode will be rejected "
                "by the API."
            )
        if len(thinking_modes) > 1:
            st.radio(
                "Thinking",
                options=thinking_modes,
                key="thinking_mode",
                format_func=str.capitalize,
                horizontal=True,
                help=(
                    "Adaptive: the model decides how much to think, steered by "
                    "the effort level below. Extended: a fixed thinking token "
                    "budget. Only the modes the selected model supports are "
                    "shown."
                ),
            )
            if st.session_state.thinking_mode == "adaptive":
                st.select_slider(
                    "Thinking Effort",
                    options=get_args(ThinkingEffort),
                    key="thinking_effort",
                )
            elif st.session_state.thinking_mode == "extended":
                st.number_input(
                    "Thinking Budget",
                    key="thinking_budget",
                    max_value=st.session_state.max_output_tokens,
                    step=1,
                )

        if st.button("Reset", type="primary"):
            with st.spinner("Resetting..."):
                st.session_state.clear()
                setup_state()

                subprocess.run("pkill Xvfb; pkill tint2", shell=True)  # noqa: ASYNC221
                await asyncio.sleep(1)
                subprocess.run("./start_all.sh", shell=True)  # noqa: ASYNC221

    if not st.session_state.auth_validated:
        if auth_error := validate_auth(
            st.session_state.provider, st.session_state.api_key
        ):
            st.warning(f"Please resolve the following auth issue:\n\n{auth_error}")
            return
        else:
            st.session_state.auth_validated = True

    chat, http_logs = st.tabs(["Chat", "HTTP Exchange Logs"])
    new_message = st.chat_input(
        "Type a message to send to Claude to control the computer..."
    )

    with chat:
        # render past chats
        for message in st.session_state.messages:
            if isinstance(message["content"], str):
                _render_message(message["role"], message["content"])
            elif isinstance(message["content"], list):
                for block in message["content"]:
                    # the tool result we send back to the Claude API isn't sufficient to render all details,
                    # so we store the tool use responses
                    if isinstance(block, dict) and block["type"] == "tool_result":
                        _render_message(
                            Sender.TOOL, st.session_state.tools[block["tool_use_id"]]
                        )
                    else:
                        _render_message(
                            message["role"],
                            cast(BetaContentBlockParam | ToolResult, block),
                        )

        # render past http exchanges
        for identity, (request, response) in st.session_state.responses.items():
            _render_api_response(request, response, identity, http_logs)

        # render past chats
        if new_message:
            st.session_state.messages.append(
                {
                    "role": Sender.USER,
                    "content": [
                        *maybe_add_interruption_blocks(),
                        BetaTextBlockParam(type="text", text=new_message),
                    ],
                }
            )
            _render_message(Sender.USER, new_message)

        try:
            most_recent_message = st.session_state["messages"][-1]
        except IndexError:
            return

        if most_recent_message["role"] is not Sender.USER:
            # we don't have a user message to respond to, exit early
            return

        with track_sampling_loop():
            # run the agent sampling loop with the newest message
            st.session_state.messages = await sampling_loop(
                system_prompt_suffix=st.session_state.custom_system_prompt,
                model=st.session_state.model,
                provider=st.session_state.provider,
                messages=st.session_state.messages,
                output_callback=partial(_render_message, Sender.BOT),
                tool_output_callback=partial(
                    _tool_output_callback, tool_state=st.session_state.tools
                ),
                api_response_callback=partial(
                    _api_response_callback,
                    tab=http_logs,
                    response_state=st.session_state.responses,
                ),
                api_key=st.session_state.api_key,
                only_n_most_recent_images=st.session_state.only_n_most_recent_images,
                tool_version=st.session_state.tool_versions,
                max_tokens=st.session_state.output_tokens,
                thinking_mode=st.session_state.thinking_mode,
                thinking_effort=st.session_state.thinking_effort,
                thinking_budget=st.session_state.thinking_budget,
                token_efficient_tools_beta=st.session_state.token_efficient_tools_beta,
            )


def maybe_add_interruption_blocks():
    if not st.session_state.in_sampling_loop:
        return []
    # If this function is called while we're in the sampling loop, we can assume that the previous sampling loop was interrupted
    # and we should annotate the conversation with additional context for the model and heal any incomplete tool use calls
    result = []
    last_message = st.session_state.messages[-1]
    previous_tool_uses = [
        block for block in last_message["content"] if block["type"] == "tool_use"
    ]
    for tool_use in previous_tool_uses:
        st.session_state.tools[tool_use["id"]] = ToolResult(error=INTERRUPT_TOOL_ERROR)
        block = BetaToolResultBlockParam(
            tool_use_id=tool_use["id"],
            type="tool_result",
            content=INTERRUPT_TOOL_ERROR,
            is_error=True,
        )
        # A toolset member call's result must carry the same toolset_name as
        # the tool_use it answers (see _make_api_tool_result in loop.py).
        toolset_name = cast(dict[str, Any], tool_use).get("toolset_name")
        if toolset_name is not None:
            cast(dict[str, Any], block)["toolset_name"] = toolset_name
        result.append(block)
    result.append(BetaTextBlockParam(type="text", text=INTERRUPT_TEXT))
    return result


@contextmanager
def track_sampling_loop():
    st.session_state.in_sampling_loop = True
    yield
    st.session_state.in_sampling_loop = False


def validate_auth(provider: APIProvider, api_key: str | None):
    if provider == APIProvider.ANTHROPIC:
        if not api_key:
            return "Enter your Claude API key in the sidebar to continue."
    if provider == APIProvider.BEDROCK:
        import boto3

        if not boto3.Session().get_credentials():
            return "You must have AWS credentials set up to use the Bedrock API."
    if provider == APIProvider.VERTEX:
        import google.auth
        from google.auth.exceptions import DefaultCredentialsError

        if not os.environ.get("CLOUD_ML_REGION"):
            return "Set the CLOUD_ML_REGION environment variable to use the Vertex API."
        try:
            google.auth.default(
                scopes=["https://www.googleapis.com/auth/cloud-platform"],
            )
        except DefaultCredentialsError:
            return "Your google cloud credentials are not set up correctly."


def load_from_storage(filename: str) -> str | None:
    """Load data from a file in the storage directory."""
    try:
        file_path = CONFIG_DIR / filename
        if file_path.exists():
            data = file_path.read_text().strip()
            if data:
                return data
    except Exception as e:
        st.write(f"Debug: Error loading {filename}: {e}")
    return None


def save_to_storage(filename: str, data: str) -> None:
    """Save data to a file in the storage directory."""
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        file_path = CONFIG_DIR / filename
        file_path.write_text(data)
        # Ensure only user can read/write the file
        file_path.chmod(0o600)
    except Exception as e:
        st.write(f"Debug: Error saving {filename}: {e}")


def _api_response_callback(
    request: httpx.Request,
    response: httpx.Response | object | None,
    error: Exception | None,
    tab: DeltaGenerator,
    response_state: dict[str, tuple[httpx.Request, httpx.Response | object | None]],
):
    """
    Handle an API response by storing it to state and rendering it.
    """
    response_id = datetime.now().isoformat()
    response_state[response_id] = (request, response)
    if error:
        _render_error(error)
    _render_api_response(request, response, response_id, tab)


def _tool_output_callback(
    tool_output: ToolResult, tool_id: str, tool_state: dict[str, ToolResult]
):
    """Handle a tool output by storing it to state and rendering it."""
    tool_state[tool_id] = tool_output
    _render_message(Sender.TOOL, tool_output)


def _render_api_response(
    request: httpx.Request,
    response: httpx.Response | object | None,
    response_id: str,
    tab: DeltaGenerator,
):
    """Render an API response to a streamlit tab"""
    with tab:
        with st.expander(f"Request/Response ({response_id})"):
            newline = "\n\n"
            st.markdown(
                f"`{request.method} {request.url}`{newline}{newline.join(f'`{k}: {v}`' for k, v in request.headers.items())}"
            )
            st.json(request.read().decode())
            st.markdown("---")
            if isinstance(response, httpx.Response):
                st.markdown(
                    f"`{response.status_code}`{newline}{newline.join(f'`{k}: {v}`' for k, v in response.headers.items())}"
                )
                st.json(response.text)
            else:
                st.write(response)


def _render_error(error: Exception):
    if isinstance(error, RateLimitError):
        body = "You have been rate limited."
        if retry_after := error.response.headers.get("retry-after"):
            body += f" **Retry after {str(timedelta(seconds=int(retry_after)))} (HH:MM:SS).** See our API [documentation](https://docs.claude.com/en/api/rate-limits) for more details."
        body += f"\n\n{error.message}"
    else:
        body = str(error)
        body += "\n\n**Traceback:**"
        lines = "\n".join(traceback.format_exception(error))
        body += f"\n\n```{lines}```"
    save_to_storage(f"error_{datetime.now().timestamp()}.md", body)
    st.error(f"**{error.__class__.__name__}**\n\n{body}", icon=":material/error:")


def _render_message(
    sender: Sender,
    message: str | BetaContentBlockParam | ToolResult,
):
    """Convert input from the user or output from the agent to a streamlit message."""
    # streamlit's hotreloading breaks isinstance checks, so we need to check for class names
    is_tool_result = not isinstance(message, str | dict)
    if not message or (
        is_tool_result
        and st.session_state.hide_images
        and not hasattr(message, "error")
        and not hasattr(message, "output")
    ):
        return
    with st.chat_message(sender):
        if is_tool_result:
            message = cast(ToolResult, message)
            if message.output:
                if message.__class__.__name__ == "CLIResult":
                    st.code(message.output)
                else:
                    st.markdown(message.output)
            if message.error:
                st.error(message.error)
            if message.base64_image and not st.session_state.hide_images:
                st.image(base64.b64decode(message.base64_image))
        elif isinstance(message, dict):
            if message["type"] == "text":
                st.write(message["text"])
            elif message["type"] == "thinking":
                thinking_content = message.get("thinking", "")
                st.markdown(f"[Thinking]\n\n{thinking_content}")
            elif message["type"] == "tool_use":
                st.code(f"Tool Use: {message['name']}\nInput: {message['input']}")
            else:
                # only expected return types are text and tool_use
                raise Exception(f"Unexpected response type {message['type']}")
        else:
            st.markdown(message)


if __name__ == "__main__":
    asyncio.run(main())
